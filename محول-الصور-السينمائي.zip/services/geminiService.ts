
import { GoogleGenAI, Modality } from "@google/genai";

const getApiKey = (): string => {
  const key = process.env.API_KEY;
  if (!key) {
    throw new Error("API_KEY environment variable not set.");
  }
  return key;
};

export const generateImage = async (
  base64Image: string,
  mimeType: string,
  prompt: string,
  temperature: number = 0.9
): Promise<{ base64: string, mimeType: string }> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        temperature: temperature,
        responseModalities: [Modality.IMAGE],
        // Using string literals for Safety Settings to match SDK expectations correctly
        safetySettings: [
          { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' }
        ],
      },
    });

    // التحقق من وجود مرشحين (Candidates)
    if (!response || !response.candidates || response.candidates.length === 0) {
      throw new Error("لم يستجب النموذج. حاول مرة أخرى.");
    }

    const candidate = response.candidates[0];

    // التحقق من وجود محتوى داخل المرشح (قد يكون محجوباً بسبب الأمان)
    if (!candidate.content || !candidate.content.parts) {
        if (candidate.finishReason) {
            // Improved error message for NO_IMAGE / Safety blocks
            throw new Error(`تعذر إنشاء الصورة (السبب: ${candidate.finishReason}). هذا يحدث عادةً إذا كان الوصف يتضمن وجوهًا قريبة جدًا أو تفاصيل واقعية يرفضها النموذج لأسباب أمنية. حاول تغيير النمط أو تقليل التفاصيل الواقعية في الوصف.`);
        }
        throw new Error("حدث خطأ أثناء معالجة الصورة. لم يتم إرجاع أي محتوى.");
    }

    for (const part of candidate.content.parts) {
      if (part.inlineData) {
        const { data, mimeType: responseMimeType } = part.inlineData;
        return { base64: data, mimeType: responseMimeType };
      }
    }

    throw new Error("لم يتم العثور على بيانات الصورة في الاستجابة.");
    
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    
    const errorString = error.message || JSON.stringify(error);
    
    if (errorString.includes("429") || errorString.includes("RESOURCE_EXHAUSTED") || errorString.includes("quota")) {
        throw new Error("عذراً، لقد تجاوزت الحد اليومي المسموح به لاستخدام الخدمة (Quota Exceeded). يرجى المحاولة مرة أخرى لاحقاً.");
    }

    if (errorString.includes("SAFETY") || errorString.includes("blocked")) {
       throw new Error("تم حظر الصورة لأسباب أمنية. يرجى تجنب التعديلات الواقعية جدًا على الوجوه.");
    }

    throw error; 
  }
};

export const enhancePrompt = async (originalPrompt: string, styleName: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [{ text: `You are an expert AI image prompt engineer.
        Rewrite the following user description into a highly detailed, professional image generation prompt optimized for the "${styleName}" style.
        
        User Description: "${originalPrompt}"
        
        Requirements:
        - Enhance details about lighting, texture, composition, and atmosphere.
        - Keep it concise but descriptive (approx 30-50 words).
        - Do NOT include markdown or explanations. Output ONLY the prompt text.` }]
      }
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || originalPrompt;
  } catch (e) {
    console.error("Enhance Prompt Error", e);
    return originalPrompt;
  }
};

export const generateTextFromImage = async (
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        // Default is text, but good to be explicit if needed or just rely on defaults for text
        safetySettings: [
          { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' }
        ],
      },
    });

    if (!response || !response.candidates || response.candidates.length === 0) {
      throw new Error("لم يستجب النموذج للنص. حاول مرة أخرى.");
    }

    const text = response.candidates[0].content?.parts?.[0]?.text;
    if (!text) {
      throw new Error("لم يتم توليد نص.");
    }

    return text;

  } catch (error: any) {
    console.error("Gemini Text API Error:", error);
     const errorString = error.message || JSON.stringify(error);
    
    if (errorString.includes("429") || errorString.includes("RESOURCE_EXHAUSTED") || errorString.includes("quota")) {
        throw new Error("عذراً، لقد تجاوزت الحد اليومي المسموح به لاستخدام الخدمة (Quota Exceeded).");
    }
    throw error;
  }
};
