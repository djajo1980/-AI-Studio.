
import React, { useState, useRef, useEffect } from 'react';
import { generateImage, enhancePrompt } from './services/geminiService';
import { fileToBase64 } from './utils/helpers';
import { UploadIcon, LoadingSpinner, DownloadIcon, RefreshIcon, MagicWandIcon, ChevronDownIcon, ExpandIcon, CloseIcon, HistoryIcon, ShirtIcon, MovieIcon, BookOpenIcon, FilmReelIcon, MasksIcon, GlobeIcon, AdjustmentsIcon, CompareIcon, FacebookIcon, YouTubeIcon, ArrowsRightLeftIcon, ShareIcon, SparklesSolidIcon, WandIcon, PhotographIcon, StickerIcon, SunIcon, MoonIcon, RobotIcon, TimelineIcon, CloudIcon, DreamIcon } from './components/icons';

type Stage = 'UPLOAD' | 'EDIT_IMAGE';
type StyleCategory = 'all' | 'tools' | 'cinematic' | 'art';
type Theme = 'dark' | 'light';

interface ImageStyle {
  id: string;
  name: string;
  description: string;
  promptSuffix: string;
  icon: React.ReactNode;
  gradient: string;
  category: StyleCategory;
}

interface HistoryItem {
  id: string;
  base64: string;
  mimeType: string;
  styleId: string;
  timestamp: number;
}

// --- Categories Definition ---
const CATEGORIES: { id: StyleCategory; label: string }[] = [
    { id: 'all', label: 'الكل' },
    { id: 'tools', label: 'أدوات' },
    { id: 'cinematic', label: 'سينما' },
    { id: 'art', label: 'فن' },
];

const STYLES: ImageStyle[] = [
  // --- Tools (Professional) ---
  { 
    id: 'scene_expand', 
    name: 'توسيع المشهد', 
    description: 'AI Expand',
    promptSuffix: '', 
    icon: <ExpandIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-blue-600 to-indigo-800',
    category: 'tools'
  },
  { 
    id: 'bg_changer', 
    name: 'استوديو الخلفيات', 
    description: 'تغيير المكان',
    promptSuffix: '', 
    icon: <PhotographIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-blue-500 to-cyan-500',
    category: 'tools'
  },
  { 
    id: 'old_photo_restore', 
    name: 'ترميم الصور', 
    description: 'تلوين وإصلاح',
    promptSuffix: '', 
    icon: <WandIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-stone-500 to-stone-700',
    category: 'tools'
  },
  { 
    id: 'color_correction', 
    name: 'تحسين وتصحيح', 
    description: 'إضاءة وجودة',
    promptSuffix: '', 
    icon: <AdjustmentsIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-teal-500 to-emerald-600',
    category: 'tools'
  },
  { 
    id: 'outfit_swap', 
    name: 'تغيير الملابس', 
    description: 'بدلة، عسكري...',
    promptSuffix: '', 
    icon: <ShirtIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-indigo-600 to-purple-700',
    category: 'tools'
  },
  { 
    id: 'visual_kinship', 
    name: 'شبيهك', 
    description: 'مقارنة تاريخية',
    promptSuffix: '', 
    icon: <CompareIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-orange-500 to-rose-500',
    category: 'tools'
  },
  { 
    id: 'movie_poster', 
    name: 'ملصق فيلم', 
    description: 'بوستر سينمائي',
    promptSuffix: '', 
    icon: <MovieIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-red-600 to-rose-900',
    category: 'tools'
  },

  // --- Cinematic & Worlds ---
  { 
    id: 'movie_continuation', 
    name: 'أكمل المشهد', 
    description: 'قصة من 3-6 مشاهد',
    promptSuffix: '', 
    icon: <TimelineIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-slate-700 to-black',
    category: 'cinematic'
  },
  { 
    id: 'dream_reconstruction', 
    name: 'إعادة بناء الحلم', 
    description: 'تجسيد كوابيس',
    promptSuffix: '', 
    icon: <DreamIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-indigo-900 to-purple-900',
    category: 'cinematic'
  },
  { 
    id: 'cinematic', 
    name: 'سينمائي', 
    description: 'إضاءة درامية',
    promptSuffix: ', artistic movie atmosphere, dramatic lighting, teal and orange color grading, deep shadows, emotional mood, wide angle shot aesthetic, atmospheric depth', 
    icon: '🎬',
    gradient: 'from-amber-500 to-red-600',
    category: 'cinematic'
  },
  { 
    id: 'memory_reconstruction', 
    name: 'ذاكرة مشهد', 
    description: 'إحياء الذكريات',
    promptSuffix: '', 
    icon: <CloudIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-slate-500 to-zinc-700',
    category: 'cinematic'
  },
  { 
    id: 'multiverse', 
    name: 'عوالم متعددة', 
    description: 'فضاء، خيال...',
    promptSuffix: '', 
    icon: <GlobeIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-violet-600 to-fuchsia-900',
    category: 'cinematic'
  },
  { 
    id: 'historical', 
    name: 'عبر الزمن', 
    description: 'مشهد تاريخي',
    promptSuffix: ', vintage aesthetic, historical documentary style, period atmosphere, desaturated colors, classic photography style, grain texture', 
    icon: <HistoryIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-yellow-600 to-amber-800',
    category: 'cinematic'
  },
  { 
    id: 'duality', 
    name: 'طيب / شرير', 
    description: 'الجانب المظلم',
    promptSuffix: '', 
    icon: <MasksIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-sky-400 to-red-600',
    category: 'cinematic'
  },
  { 
    id: 'cyberpunk', 
    name: 'سايبر بانك', 
    description: 'نيون ومستقبل',
    promptSuffix: ', cyberpunk aesthetic, neon lighting, futuristic elements, night atmosphere, glowing lights, sci-fi mood', 
    icon: '🤖',
    gradient: 'from-fuchsia-600 to-purple-600',
    category: 'cinematic'
  },

  // --- Art & Fun ---
  { 
    id: 'ai_avatar', 
    name: 'أفاتار ذكي', 
    description: 'مثل Lensa AI',
    promptSuffix: '', 
    icon: <RobotIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-pink-500 to-violet-600',
    category: 'art'
  },
  { 
    id: 'sticker', 
    name: 'ملصق واتساب', 
    description: 'حدود بيضاء',
    promptSuffix: '', 
    icon: <StickerIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-lime-500 to-green-600',
    category: 'art'
  },
  { 
    id: 'style_transfer', 
    name: 'أنماط أفلام', 
    description: 'بيكسار، GTA...',
    promptSuffix: '', 
    icon: <FilmReelIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-pink-600 to-rose-500',
    category: 'art'
  },
  { 
    id: 'comic_story', 
    name: 'قصة مصورة', 
    description: 'صفحة مانجا',
    promptSuffix: '', 
    icon: <BookOpenIcon className="w-5 h-5 sm:w-6 sm:h-6" />,
    gradient: 'from-slate-600 to-slate-900',
    category: 'art'
  },
  { 
    id: 'anime', 
    name: 'أنمي', 
    description: 'رسوم يابانية',
    promptSuffix: ', anime art style, hand drawn aesthetic, vibrant colors, detailed background, cel shaded illustration', 
    icon: '🗾',
    gradient: 'from-indigo-500 to-blue-600',
    category: 'art'
  },
  { 
    id: 'cartoon', 
    name: 'كرتون', 
    description: 'رسوم بسيطة',
    promptSuffix: ', flat cartoon style, bold outlines, vector art style, simple colors, illustrative', 
    icon: '🎨',
    gradient: 'from-yellow-400 to-orange-500',
    category: 'art'
  },
  { 
    id: 'caricature', 
    name: 'كاريكاتير', 
    description: 'فكاهي مبالغ',
    promptSuffix: ', caricature art style, exaggerated features, humorous illustration, artistic sketch', 
    icon: '✏️',
    gradient: 'from-gray-500 to-gray-700',
    category: 'art'
  },
  { 
    id: 'oil_painting', 
    name: 'رسم زيتي', 
    description: 'لوحة كلاسيكية',
    promptSuffix: ', oil painting style, brush strokes, canvas texture, classical art aesthetic, artistic composition', 
    icon: '🖼️',
    gradient: 'from-emerald-500 to-teal-600',
    category: 'art'
  },
];

// --- Options ---
const AGES = [
    { label: 'نفس العمر', value: '' },
    { label: 'طفل صغير', value: 'appearing as a young child' },
    { label: 'مراهق', value: 'appearing as a teenager' },
    { label: 'شاب بالغ', value: 'appearing as a young adult' },
    { label: 'مسن', value: 'appearing elderly' },
];

const ROLES = [
    { label: 'بدون دور', value: '' },
    { label: 'ثائر', value: 'wearing resistance style clothing, determined expression' },
    { label: 'مفكر', value: 'holding a book, thoughtful expression, wearing smart clothes' },
    { label: 'حنون', value: 'caring expression, warm atmosphere' },
    { label: 'فنان', value: 'wearing artistic clothes, creative atmosphere' },
    { label: 'فلاح', value: 'wearing traditional rural clothes, simple atmosphere' },
    { label: 'رحالة', value: 'wearing travel gear, adventurous atmosphere' },
];

const OUTFIT_OPTIONS = [
    { id: 'suit', label: 'بدلة رسمية', prompt: 'wearing a high-quality tailored formal business suit and tie, professional look' },
    { id: 'military', label: 'زي عسكري', prompt: 'wearing a detailed military uniform with badges, disciplined soldier look' },
    { id: 'arab', label: 'زي عربي', prompt: 'wearing traditional Arab clothing (White Thobe and Shemagh), cultural elegance' },
    { id: 'sport', label: 'رياضي', prompt: 'wearing modern athletic sportswear, fitness look' },
    { id: 'knight', label: 'فارس', prompt: 'wearing epic fantasy knight armor, medieval metallic texture, heroic look' },
    { id: 'wizard', label: 'ساحر', prompt: 'wearing mystical wizard robes with magical symbols, fantasy atmosphere' },
];

const BG_OPTIONS = [
    { id: 'office', label: 'مكتب فاخر', prompt: 'in a modern luxury office with city view window' },
    { id: 'beach', label: 'شاطئ', prompt: 'on a beautiful tropical beach with turquoise water and palm trees' },
    { id: 'studio', label: 'استوديو', prompt: 'with a solid clean photography studio background, professional lighting' },
    { id: 'paris', label: 'باريس', prompt: 'in the streets of Paris with the Eiffel Tower in the distance' },
    { id: 'space', label: 'فضاء', prompt: 'in outer space with nebula and stars in the background' },
    { id: 'forest', label: 'غابة', prompt: 'in a magical serene forest with sunlight filtering through trees' },
];

const COMIC_STYLES = [
    { id: 'manga', label: 'مانجا', prompt: 'Japanese Manga style, black and white, detailed inking, screen tones' },
    { id: 'webtoon', label: 'ويب تون', prompt: 'Korean Webtoon style, vibrant colors, digital art, vertical flow aesthetic' },
    { id: 'us_comic', label: 'كوميكس', prompt: 'American comic book style, bold ink lines, dynamic shading, vibrant colors' },
    { id: 'graphic_novel', label: 'رواية', prompt: 'Graphic novel style, artistic, moody atmosphere, painterly textures' },
];

const CHARACTER_STYLES = [
    { id: 'pixar', label: 'بيكسار', prompt: 'Pixar 3D animation style, soft textures, big expressive eyes, cute and vibrant, 3D render, Disney Pixar aesthetic' },
    { id: 'disney', label: 'ديزني', prompt: 'Modern Disney Animation style (like Frozen/Moana), 3D artistic, magical atmosphere, smooth skin texture, expressive face' },
    { id: 'spiderverse', label: 'سبايدرمان', prompt: 'Spider-Man: Into the Spider-Verse art style, halftone dots, chromatic aberration, graffiti art style, comic book aesthetic, vibrant neon colors, stylized motion' },
    { id: 'anime_movie', label: 'فيلم أنمي', prompt: 'High budget Anime movie style (Makoto Shinkai style), detailed background, lens flares, vibrant skies, emotional atmosphere, cel shaded' },
    { id: 'gta', label: 'GTA', prompt: 'Grand Theft Auto (GTA) loading screen art style, vector illustration, heavy outlines, stylized shading, realistic proportions' },
    { id: 'realism_4k', label: 'واقعية 4K', prompt: 'Unreal Engine 5 render, hyper-realistic CGI character, cinematic movie shot, highly detailed skin texture, dramatic lighting, 8k resolution' }
];

const MULTIVERSE_DIMENSIONS = [
  { id: 'fantasy', label: 'عالم خيالي', prompt: 'High fantasy world, magical forest background, wearing ornate armor or robes, glowing magical aura, ethereal lighting, epic atmosphere' },
  { id: 'alien', label: 'عالم فضائي', prompt: 'Sci-fi alien planet, bioluminescent plants in background, wearing futuristic space suit, starry sky with two moons, cosmic lighting, futuristic atmosphere' },
  { id: 'cartoon', label: 'عالم كرتوني', prompt: 'Vibrant 2D cartoon world, bright colors, simplified shapes, cheerful atmosphere, stylized vector art background' },
  { id: 'realistic', label: 'عالم واقعي', prompt: 'Modern day realistic world, busy city street background, casual contemporary clothing, natural lighting, high quality photography style' },
  { id: 'dystopian', label: 'عالم ديستوبي', prompt: 'Post-apocalyptic dystopian world, ruined city background, wearing survival gear, dusty and gritty atmosphere, dramatic sunset lighting, Mad Max aesthetic' }
];

const COLOR_CORRECTION_PRESETS = [
  { id: 'natural', label: 'إضاءة طبيعية', prompt: 'enhance natural lighting, balance exposure, correct white balance, soft daylight aesthetic, natural skin tones' },
  { id: 'grading', label: 'تصحيح الألوان', prompt: 'professional color grading, rich vibrant colors, perfect color harmony, artistic color balance' },
  { id: 'celebrity', label: 'نمط المشاهير', prompt: 'celebrity magazine portrait style, glamorous lighting, smooth skin texture, high-end retouching look, glowing skin' },
  { id: 'cinematic', label: 'نمط سينمائي', prompt: 'cinematic teal and orange grading, dramatic atmosphere, deep blacks, movie scene color palette' },
  { id: 'studio', label: 'جودة استوديو', prompt: 'professional studio photography look, clean background isolation feeling, softbox lighting, high sharpness, pristine quality' },
  { id: 'clarity', label: 'إزالة التشويش', prompt: 'denoise, sharpen details, remove blur, upscale quality, crystal clear clarity, high definition' },
];

const KINSHIP_CATEGORIES = [
    { id: 'history', label: 'شخصية تاريخية' },
    { id: 'art', label: 'لوحة فنية' },
    { id: 'cinema', label: 'نجم سينمائي' },
    { id: 'literature', label: 'شخصية أدبية' },
];

const AVATAR_STYLES = [
    { id: 'cosmic', label: 'كوني', prompt: 'Cosmic energy, galaxy background, glowing eyes, star dust, ethereal, digital art, trending on ArtStation' },
    { id: 'cyber', label: 'سايبر', prompt: 'Futuristic cyberpunk, neon lights, mechanical parts, high tech, city background, digital illustration' },
    { id: 'royal', label: 'ملكي', prompt: 'Royal oil painting, crown, golden armor, regal atmosphere, classical art style, masterpiece' },
    { id: 'pop', label: 'بوب آرت', prompt: 'Pop Art style, vibrant colors, halftone dots, comic book aesthetic, bold lines, Andy Warhol style' },
    { id: 'fantasy', label: 'أسطوري', prompt: 'Fantasy elf or warrior, magical aura, detailed armor, mysterious background, digital fantasy art' },
    { id: 'mystic', label: 'صوفي', prompt: 'Mystical atmosphere, glowing runes, spiritual energy, dreamlike background, ethereal lighting' },
];

// --- المكونات المساعدة ---

const SkeletonLoader: React.FC = () => (
    <div className="absolute inset-0 w-full h-full bg-base-200 rounded-2xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-base-100/10 to-transparent animate-shimmer" style={{ backgroundSize: '200% 100%' }}></div>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-text-secondary opacity-70">
             <div className="w-20 h-20 rounded-full border-4 border-base-300 animate-pulse-slow mb-4 relative">
                <div className="absolute inset-0 rounded-full border-t-4 border-primary animate-spin"></div>
             </div>
             <p className="text-sm animate-pulse">جاري المعالجة الذكية...</p>
        </div>
    </div>
);

const CompareSlider: React.FC<{
    originalSrc: string;
    generatedSrc: string;
    className?: string;
}> = ({ originalSrc, generatedSrc, className }) => {
    const [sliderPosition, setSliderPosition] = useState(50);
    const [isDragging, setIsDragging] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    const handleMove = (event: React.MouseEvent | React.TouchEvent) => {
        if (!containerRef.current) return;
        
        const containerRect = containerRef.current.getBoundingClientRect();
        const clientX = 'touches' in event ? event.touches[0].clientX : event.clientX;
        
        let position = ((clientX - containerRect.left) / containerRect.width) * 100;
        position = Math.max(0, Math.min(100, position));
        setSliderPosition(position);
    };

    const handleMouseDown = () => setIsDragging(true);
    const handleMouseUp = () => setIsDragging(false);

    useEffect(() => {
        const handleGlobalMouseUp = () => setIsDragging(false);
        const handleGlobalMouseMove = (e: MouseEvent) => {
            if (isDragging) {
                // @ts-ignore
                handleMove(e);
            }
        }
        // @ts-ignore
        const handleGlobalTouchMove = (e: TouchEvent) => {
             if (isDragging) {
                // @ts-ignore
                handleMove(e);
             }
        }

        window.addEventListener('mouseup', handleGlobalMouseUp);
        window.addEventListener('mousemove', handleGlobalMouseMove);
        window.addEventListener('touchmove', handleGlobalTouchMove);
        window.addEventListener('touchend', handleGlobalMouseUp);

        return () => {
            window.removeEventListener('mouseup', handleGlobalMouseUp);
            window.removeEventListener('mousemove', handleGlobalMouseMove);
            window.removeEventListener('touchmove', handleGlobalTouchMove);
            window.removeEventListener('touchend', handleGlobalMouseUp);
        };
    }, [isDragging]);


    return (
        <div 
            ref={containerRef}
            className={`relative w-full h-full overflow-hidden cursor-ew-resize select-none ${className}`}
            onMouseDown={handleMouseDown}
            onTouchStart={handleMouseDown}
            onClick={(e) => handleMove(e)}
        >
            <img src={originalSrc} alt="Original" className="absolute inset-0 w-full h-full object-contain select-none pointer-events-none" />
            <div 
                className="absolute inset-0 w-full h-full overflow-hidden select-none pointer-events-none"
                style={{ width: `${sliderPosition}%` }}
            >
                <img src={generatedSrc} alt="Generated" className="absolute inset-0 max-w-none h-full object-contain select-none" style={{ width: `${10000/sliderPosition}%` }} />
            </div>
             <div className="absolute inset-0 w-full h-full pointer-events-none">
                 <img src={generatedSrc} className="w-full h-full object-contain" style={{ clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)` }} />
             </div>
            <div 
                className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize shadow-[0_0_10px_rgba(0,0,0,0.5)] z-10 pointer-events-none"
                style={{ left: `${sliderPosition}%` }}
            >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-full p-1.5 shadow-lg">
                    <ArrowsRightLeftIcon className="w-4 h-4 text-primary" />
                </div>
            </div>
            <div className="absolute top-4 left-4 bg-black/50 text-white text-xs px-2 py-1 rounded pointer-events-none backdrop-blur-sm">بعد</div>
            <div className="absolute top-4 right-4 bg-black/50 text-white text-xs px-2 py-1 rounded pointer-events-none backdrop-blur-sm">قبل</div>
        </div>
    );
};

const PromptInput: React.FC<{ 
    value: string; 
    onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void; 
    placeholder: string; 
    label: string; 
    rows?: number;
    onEnhance?: () => void;
    isEnhancing?: boolean;
}> = ({ value, onChange, placeholder, label, rows = 3, onEnhance, isEnhancing }) => (
  <div className="w-full group">
    <label className="block text-xs font-bold text-text-secondary mb-1.5 px-1 group-focus-within:text-primary transition-colors">{label}</label>
    <div className="relative">
        <textarea
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          rows={rows}
          dir="rtl"
          className="w-full p-3 bg-base-200 border border-base-300 rounded-xl text-text-main focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all resize-none shadow-sm text-sm placeholder:text-text-secondary/50 outline-none"
        />
        {onEnhance && (
            <button 
                onClick={onEnhance}
                disabled={isEnhancing || !value}
                className={`absolute bottom-2 left-2 p-1.5 rounded-lg transition-all shadow-md
                ${isEnhancing ? 'bg-base-300 text-text-secondary cursor-wait' : 'bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:brightness-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed'}`}
                title="تحسين الوصف"
            >
                {isEnhancing ? <LoadingSpinner className="w-4 h-4" /> : <SparklesSolidIcon className="w-4 h-4" />}
            </button>
        )}
    </div>
  </div>
);

const Lightbox: React.FC<{ src: string | null; onClose: () => void }> = ({ src, onClose }) => {
    if (!src) return null;
    return (
        <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-2 sm:p-4 backdrop-blur-xl animate-fadeIn" onClick={onClose}>
            <button onClick={onClose} className="absolute top-4 right-4 sm:top-6 sm:right-6 text-white hover:text-red-400 transition-colors z-50 bg-white/10 hover:bg-white/20 rounded-full p-3 backdrop-blur-lg">
                <CloseIcon className="w-6 h-6 sm:w-8 sm:h-8" />
            </button>
            <img src={src} alt="Full view" className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" onClick={(e) => e.stopPropagation()} />
        </div>
    );
};

const StyleCard: React.FC<{ style: ImageStyle; isSelected: boolean; onClick: () => void }> = ({ style, isSelected, onClick }) => (
    <div 
        onClick={onClick}
        className={`cursor-pointer relative overflow-hidden rounded-xl border transition-all duration-200 active:scale-95 touch-manipulation hover:scale-[1.02] hover:shadow-md
        flex flex-col gap-2 items-center text-center justify-center p-2 min-h-[100px] group
        ${isSelected 
            ? `border-primary bg-primary/10 shadow-[0_0_15px_rgba(79,70,229,0.15)] ring-1 ring-primary/50` 
            : 'border-border-base bg-base-200/50 hover:bg-base-300/50 hover:border-primary/30'}`}
    >
        {isSelected && <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-primary animate-pulse shadow-[0_0_8px_rgba(79,70,229,1)]" />}
        <div className={`text-xl p-2.5 rounded-xl bg-gradient-to-br ${style.gradient} text-white shadow-lg flex items-center justify-center w-10 h-10 mb-1 transition-transform group-hover:scale-110 duration-300`}>
            {style.icon}
        </div>
        <div className="w-full">
            <h4 className={`font-bold text-xs leading-tight ${isSelected ? 'text-primary' : 'text-text-main'}`}>{style.name}</h4>
        </div>
    </div>
);

const CategoryTabs: React.FC<{ 
    activeCategory: StyleCategory; 
    onSelect: (cat: StyleCategory) => void; 
}> = ({ activeCategory, onSelect }) => (
    <div className="flex gap-1.5 overflow-x-auto pb-2 mb-2 scrollbar-hide border-b border-border-base sticky top-0 bg-base-100/95 backdrop-blur z-10 pt-1">
        {CATEGORIES.map(cat => (
            <button 
                key={cat.id} 
                onClick={() => onSelect(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-300 flex-shrink-0 border ${activeCategory === cat.id ? 'bg-primary text-white border-primary shadow-sm' : 'bg-base-200 text-text-secondary border-transparent hover:bg-base-300'}`}
            >
                {cat.label}
            </button>
        ))}
    </div>
);

const CreativitySlider: React.FC<{ value: number; onChange: (v: number) => void }> = ({ value, onChange }) => {
    const getLabel = (val: number) => {
        if (val <= 0.3) return { text: 'دقيق', color: 'text-emerald-500' };
        if (val <= 0.7) return { text: 'متوازن', color: 'text-amber-500' };
        return { text: 'جامح', color: 'text-purple-500' };
    };
    const labelInfo = getLabel(value);

    return (
        <div className="p-3 bg-base-200/50 rounded-xl border border-border-base mb-4 hover:border-primary/30 transition-colors">
            <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-text-main flex items-center gap-1.5">
                    <MagicWandIcon className="w-3 h-3 text-primary" />
                    مستوى الإبداع
                </label>
                <span className={`text-[10px] font-bold ${labelInfo.color}`}>{labelInfo.text}</span>
            </div>
            <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.1" 
                value={value} 
                onChange={(e) => onChange(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-base-300 rounded-lg appearance-none cursor-pointer accent-primary hover:accent-primary-focus"
            />
        </div>
    );
};

// --- المكون الرئيسي للتطبيق ---

export default function App() {
  const [theme, setTheme] = useState<Theme>('dark');
  const [originalImage, setOriginalImage] = useState<{ file: File; base64: string; mimeType: string; } | null>(null);
  const [imagePrompt, setImagePrompt] = useState<string>('');
  const [selectedStyle, setSelectedStyle] = useState<ImageStyle>(STYLES[0]);
  const [activeCategory, setActiveCategory] = useState<StyleCategory>('all');
  const [creativityLevel, setCreativityLevel] = useState<number>(0.7);
  
  const [generatedImage, setGeneratedImage] = useState<{ base64: string; mimeType: string; } | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  // Style Specific States
  const [historicalEra, setHistoricalEra] = useState<string>('');
  const [historicalPlace, setHistoricalPlace] = useState<string>('');
  const [selectedAge, setSelectedAge] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<string>('');
  const [selectedOutfit, setSelectedOutfit] = useState<string>('suit');
  const [selectedBg, setSelectedBg] = useState<string>('office');
  const [selectedCharStyle, setSelectedCharStyle] = useState<string>('pixar');
  const [selectedDimension, setSelectedDimension] = useState<string>('fantasy');
  const [selectedColorPreset, setSelectedColorPreset] = useState<string>('natural');
  const [posterTitle, setPosterTitle] = useState<string>('');
  const [posterCharacter, setPosterCharacter] = useState<string>('');
  const [posterTagline, setPosterTagline] = useState<string>('');
  const [comicPlot, setComicPlot] = useState<string>('');
  const [comicStyleType, setComicStyleType] = useState<string>('manga');
  const [dualityMode, setDualityMode] = useState<'good' | 'evil'>('good');
  const [selectedKinshipCategory, setSelectedKinshipCategory] = useState<string>('history');
  const [selectedAvatarStyle, setSelectedAvatarStyle] = useState<string>('cosmic');
  
  const [isLoadingImage, setIsLoadingImage] = useState<boolean>(false);
  const [isEnhancingPrompt, setIsEnhancingPrompt] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null);
  const [isCompareMode, setIsCompareMode] = useState<boolean>(false);

  // State for drag and drop
  const [isDragging, setIsDragging] = useState<boolean>(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    if (theme === 'dark') {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
      setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const filteredStyles = STYLES.filter(style => activeCategory === 'all' || style.category === activeCategory);

  const processFile = async (file: File) => {
      setError(null);
      // Don't clear generated immediately to allow compare with old one if needed, but usually new upload means reset
      setGeneratedImage(null);
      setHistory([]); 
      try {
        const { base64, mimeType } = await fileToBase64(file);
        setOriginalImage({ file, base64, mimeType });
      } catch (err) {
        setError('فشل في قراءة ملف الصورة.');
      }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
      e.preventDefault();
      setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLLabelElement>) => {
      e.preventDefault();
      setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files?.[0];
      if (file && file.type.startsWith('image/')) {
          processFile(file);
      } else if (file) {
          setError('يرجى رفع ملف صورة صالح (PNG, JPG, etc).');
      }
  };

  const addToHistory = (image: { base64: string, mimeType: string }, styleId: string) => {
      const newItem: HistoryItem = {
          id: Date.now().toString(),
          base64: image.base64,
          mimeType: image.mimeType,
          styleId: styleId,
          timestamp: Date.now()
      };
      setHistory(prev => [newItem, ...prev].slice(10));
  };

  const handleEnhancePrompt = async () => {
      if (!imagePrompt) return;
      setIsEnhancingPrompt(true);
      try {
          const enhanced = await enhancePrompt(imagePrompt, selectedStyle.name);
          setImagePrompt(enhanced);
      } catch (err) {
          console.error(err);
      } finally {
          setIsEnhancingPrompt(false);
      }
  };

  const handleGenerateImage = async () => {
    if (!originalImage) {
      setError('يرجى رفع صورة أولاً.');
      return;
    }
    setIsLoadingImage(true);
    setError(null);
    
    try {
      let finalPrompt = "";
      
      if (selectedStyle.id === 'bg_changer') {
        const bgPrompt = BG_OPTIONS.find(b => b.id === selectedBg)?.prompt || 'new background';
        finalPrompt = `Change background to: ${bgPrompt}. KEEP THE SUBJECT EXACTLY AS IS. Do not change the person's face, body, or clothing. High quality composition. ${imagePrompt}`;
      } else if (selectedStyle.id === 'scene_expand') {
        finalPrompt = `Zoom out and expand the scene. Create a wide-angle cinematic shot that includes the original subject in the center but reveals much more of the surrounding environment. seamlessly extend the background to the left and right. High quality, detailed background. ${imagePrompt}`;
      } else if (selectedStyle.id === 'sticker') {
        finalPrompt = `Create a die-cut sticker of the subject. White border, transparent background feeling, vector art style, expressive facial features, high contrast. ${imagePrompt}`;
      } else if (selectedStyle.id === 'outfit_swap') {
        const outfitPrompt = OUTFIT_OPTIONS.find(o => o.id === selectedOutfit)?.prompt || 'wearing new clothes';
        finalPrompt = `Professional photo edit. Change the subject's clothing to be ${outfitPrompt}. Keep the face and head consistent and realistic. Professional lighting, high quality photo.`;
        if (imagePrompt) finalPrompt += ` ${imagePrompt}`;
      } else if (selectedStyle.id === 'multiverse') {
        const dimPrompt = MULTIVERSE_DIMENSIONS.find(d => d.id === selectedDimension)?.prompt || 'Fantasy world';
        finalPrompt = `Re-imagine this person in a ${dimPrompt}. Keep the person's recognizable facial features. Background and clothing should match the chosen world perfectly. High quality artistic composition. ${imagePrompt}`;
      } else if (selectedStyle.id === 'style_transfer') {
        const stylePrompt = CHARACTER_STYLES.find(s => s.id === selectedCharStyle)?.prompt || 'Pixar style';
        finalPrompt = `Re-imagine this person as a character in the style of: ${stylePrompt}. Keep the person's identifiable features but adapted to the chosen art style. ${imagePrompt}`;
      } else if (selectedStyle.id === 'duality') {
        finalPrompt = dualityMode === 'good' 
            ? `Create a "Good/Heroic" version. Style: Marvel Superhero aesthetics, bright golden and blue cinematic lighting, angelic aura, heroic stance. ${imagePrompt}`
            : `Create an "Evil/Villain" version. Style: Marvel Supervillain aesthetics, dark and dramatic lighting, red/purple glow, sinister expression. ${imagePrompt}`;
      } else if (selectedStyle.id === 'movie_poster') {
        finalPrompt = `Create a professional cinematic movie poster featuring the subject. Style: High-budget blockbuster poster. Text Overlay: Title "${posterTitle}", Character "${posterCharacter}", Tagline "${posterTagline}". Cinematic font. ${imagePrompt}`;
      } else if (selectedStyle.id === 'comic_story') {
        const styleDesc = COMIC_STYLES.find(s => s.id === comicStyleType)?.prompt || 'Manga style';
        const storyDesc = comicPlot || 'Action scenes';
        finalPrompt = `Create a single-page comic/manga layout (4-6 panels). Subject based on input image. Story: ${storyDesc}. Art Style: ${styleDesc}. Professional layout with borders. ${imagePrompt}`;
      } else if (selectedStyle.id === 'historical') {
        let identityPrompt = selectedAge + (selectedRole ? `, ${selectedRole}` : '');
        const context = `set in ${historicalEra || 'the past'} in ${historicalPlace || 'historical location'}`;
        finalPrompt = `Edit to reflect a ${context}. ${imagePrompt}. ${identityPrompt}. Period details, documentary atmosphere. ${selectedStyle.promptSuffix}`;
      } else if (selectedStyle.id === 'color_correction') {
        const presetPrompt = COLOR_CORRECTION_PRESETS.find(p => p.id === selectedColorPreset)?.prompt || 'enhance quality';
        finalPrompt = `Apply professional photo enhancement: ${presetPrompt}. Maintain natural subject look. Improve lighting, grading, clarity. High-quality photography. ${imagePrompt}`;
      } else if (selectedStyle.id === 'visual_kinship') {
        const category = KINSHIP_CATEGORIES.find(c => c.id === selectedKinshipCategory)?.label || 'historical figure';
        finalPrompt = `Create a split-screen artistic composition. Left: Subject in classic artistic style. Right: A famous ${category} figure/painting sharing similar mood/pose. Consistent art style for both. Spiritual resemblance. ${imagePrompt}`;
      } else if (selectedStyle.id === 'old_photo_restore') {
          finalPrompt = `Restore this old photo. Remove scratches, fix tears, denoise, sharpen. Colorize naturally if B&W. High-resolution digital scan look. Maintain identity. ${imagePrompt}`;
      } else if (selectedStyle.id === 'ai_avatar') {
          const avatarStyle = AVATAR_STYLES.find(a => a.id === selectedAvatarStyle)?.prompt || 'Digital art';
          finalPrompt = `Create a stylized AI Avatar of this person. Style: ${avatarStyle}. High detailed digital art, trending on ArtStation, highly stylized portrait, keep facial features recognizable but artistic. ${imagePrompt}`;
      } else if (selectedStyle.id === 'movie_continuation') {
          finalPrompt = `Create a cinematic storyboard sheet containing a sequence of 3 to 6 panels.
          The sequence must tell a story:
          1. The Beginning (Before the uploaded image).
          2. The Climax (The uploaded image integrated into the scene).
          3. The Aftermath (What happened afterwards).
          Style: Photorealistic movie stills arranged in a comic-book grid layout.
          High definition, 8k, cinematic lighting.
          Narrative Context: ${imagePrompt || 'A dramatic event'}.`;
      } else if (selectedStyle.id === 'memory_reconstruction') {
          finalPrompt = `Reconstruct a nostalgic memory based on this image.
          User Memory Description: "${imagePrompt || 'A beautiful old memory'}".
          Style: Authentic vintage photograph, 35mm film grain, slightly faded colors, polaroid aesthetic, dreamlike and emotional atmosphere, soft focus.
          If the user specified an age, adjust the subject's appearance naturally to match that age while keeping resemblance.
          Background: Reconstruct the setting to match the description in a nostalgic way.`;
      } else if (selectedStyle.id === 'dream_reconstruction') {
          finalPrompt = `Visualise the user's dream as a cinematic storyboard sequence (3-6 panels on one page).
          Dream Description: "${imagePrompt}".
          Subject: The person in the uploaded image.
          Style: Dark fantasy, Dreamcore, Surreal realism, highly detailed, atmospheric lighting (nightmare/dream mood).
          Layout: Comic book grid sequence.
          Panel 1: The beginning of the dream.
          Panel 2-5: The action/climax.
          Panel 6: The awakening or end.`;
      } else {
        let identityPrompt = selectedAge + (selectedRole ? `, ${selectedRole}` : '');
        finalPrompt = `Apply a ${selectedStyle.name} style edit. ${imagePrompt}. ${identityPrompt} ${selectedStyle.promptSuffix}`;
      }

      const result = await generateImage(originalImage.base64, originalImage.mimeType, finalPrompt, creativityLevel);
      setGeneratedImage(result);
      addToHistory(result, selectedStyle.id);
      
    } catch (err: any) {
      setError(`فشل العملية: ${err.message}`);
    } finally {
      setIsLoadingImage(false);
    }
  };
  
  const handleReset = () => {
    setOriginalImage(null);
    setGeneratedImage(null);
    setHistory([]);
    setImagePrompt('');
    setError(null);
    setIsCompareMode(false);
  };

  const handleDownloadImage = (base64: string, mimeType: string, filename: string) => {
      const link = document.createElement('a');
      link.href = `data:${mimeType};base64,${base64}`;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  const handleShareImage = async (base64: string, mimeType: string) => {
      try {
          const blob = await (await fetch(`data:${mimeType};base64,${base64}`)).blob();
          const file = new File([blob], 'image.png', { type: mimeType });
          if (navigator.share) await navigator.share({ files: [file] });
      } catch (err) { console.error(err); }
  };

  return (
    <div className="h-screen bg-base-100 text-text-main font-sans selection:bg-primary selection:text-white flex flex-col lg:flex-row overflow-hidden transition-colors duration-300" dir="rtl">
      <Lightbox src={lightboxSrc} onClose={() => setLightboxSrc(null)} />
      
      {/* === SIDEBAR (CONTROLS) === */}
      <aside className="w-full lg:w-[400px] bg-base-100 border-l border-border-base flex flex-col h-[45vh] lg:h-full z-20 shadow-2xl lg:shadow-none order-2 lg:order-1 transition-colors duration-300">
         
         {/* Header & Project Controls */}
         <div className="shrink-0 p-4 border-b border-border-base bg-base-100/95 backdrop-blur flex justify-between items-center">
            <div className="flex items-center gap-2">
                <div className="p-1.5 bg-primary/10 rounded-lg">
                    <MagicWandIcon className="w-5 h-5 text-primary" />
                </div>
                <div>
                    <h1 className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">محول الصور</h1>
                    <p className="text-[10px] text-text-secondary">Studio v2.0</p>
                </div>
            </div>
            <div className="flex gap-2">
                <button onClick={toggleTheme} className="p-2 rounded-lg bg-base-200 text-text-secondary hover:text-primary transition-colors">
                    {theme === 'dark' ? <SunIcon className="w-4 h-4" /> : <MoonIcon className="w-4 h-4" />}
                </button>
                <button 
                    onClick={handleReset} 
                    className="flex items-center gap-2 text-xs font-bold text-white hover:text-white px-3 py-1.5 bg-red-500/90 hover:bg-red-500 rounded-lg transition-colors shadow-lg"
                    title="بدء مشروع جديد"
                >
                    <RefreshIcon className="w-3.5 h-3.5" />
                    جديد
                </button>
            </div>
         </div>

         {/* Scrollable Content Area */}
         <div className="flex-1 overflow-y-auto scrollbar-hide p-4 space-y-6">
            
            {/* 1. Upload / Original Preview */}
            <div className="space-y-2 animate-fadeInUp" style={{ animationDelay: '0.1s' }}>
                {!originalImage ? (
                    <label 
                        className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-2xl transition-all cursor-pointer group relative overflow-hidden
                        ${isDragging ? 'border-primary bg-primary/5 scale-[1.02]' : 'border-border-base hover:bg-base-200/50 hover:border-primary/50'}`}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                    >
                        <div className={`pointer-events-none flex flex-col items-center transition-transform duration-300 ${isDragging ? 'scale-110' : 'group-hover:scale-105'}`}>
                            <div className="p-3 rounded-full bg-base-200 mb-3 shadow-sm group-hover:shadow-md transition-shadow">
                                <UploadIcon className={`w-6 h-6 ${isDragging ? 'text-primary' : 'text-text-secondary'}`} />
                            </div>
                            <span className="text-sm font-bold text-text-main">ارفع صورة</span>
                            <span className="text-[10px] text-text-secondary mt-1">JPG, PNG (اسحب هنا)</span>
                        </div>
                        <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                    </label>
                ) : (
                    <div className="flex items-center gap-3 p-2 bg-base-200/50 rounded-xl border border-border-base shadow-sm group hover:border-primary/30 transition-colors">
                        <img src={`data:${originalImage.mimeType};base64,${originalImage.base64}`} alt="Original" className="w-14 h-14 rounded-lg object-cover shadow-sm" />
                        <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold truncate text-text-main mb-1">{originalImage.file.name}</p>
                            <div className="flex gap-2">
                                <label className="text-[10px] px-2 py-1 bg-base-300 rounded text-text-main cursor-pointer hover:bg-primary hover:text-white transition-colors flex items-center gap-1">
                                    <RefreshIcon className="w-3 h-3" />
                                    تغيير
                                    <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                                </label>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* 2. Styles */}
            <div className="space-y-3 animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
                <CategoryTabs activeCategory={activeCategory} onSelect={setActiveCategory} />
                <div className="grid grid-cols-3 gap-2">
                    {filteredStyles.map((style) => (
                        <StyleCard 
                            key={style.id} 
                            style={style} 
                            isSelected={selectedStyle.id === style.id}
                            onClick={() => setSelectedStyle(style)}
                        />
                    ))}
                </div>
            </div>

            {/* 3. Style Options (Dynamic) */}
            <div className="animate-fadeInUp" style={{ animationDelay: '0.3s' }}>
                {selectedStyle.id === 'bg_changer' && (
                    <div className="bg-base-200/30 rounded-xl p-3 grid grid-cols-2 gap-2 border border-border-base">
                        {BG_OPTIONS.map(bg => (
                            <button key={bg.id} onClick={() => setSelectedBg(bg.id)} className={`p-2 rounded-lg text-[10px] font-bold border transition-all ${selectedBg === bg.id ? 'bg-cyan-600 text-white border-cyan-500' : 'border-border-base text-text-secondary hover:bg-base-200'}`}>{bg.label}</button>
                        ))}
                    </div>
                )}
                {selectedStyle.id === 'color_correction' && (
                    <div className="bg-base-200/30 rounded-xl p-3 grid grid-cols-2 gap-2 border border-border-base">
                        {COLOR_CORRECTION_PRESETS.map(p => (
                            <button key={p.id} onClick={() => setSelectedColorPreset(p.id)} className={`p-2 rounded-lg text-[10px] font-bold border transition-all ${selectedColorPreset === p.id ? 'bg-emerald-600 border-emerald-500 text-white' : 'border-border-base text-text-secondary hover:bg-base-200'}`}>{p.label}</button>
                        ))}
                    </div>
                )}
                {selectedStyle.id === 'outfit_swap' && (
                    <div className="bg-base-200/30 rounded-xl p-3 grid grid-cols-2 gap-2 border border-border-base">
                        {OUTFIT_OPTIONS.map(o => (
                            <button key={o.id} onClick={() => setSelectedOutfit(o.id)} className={`p-2 rounded-lg text-[10px] font-bold border transition-all ${selectedOutfit === o.id ? 'bg-indigo-600 text-white' : 'border-border-base text-text-secondary hover:bg-base-200'}`}>{o.label}</button>
                        ))}
                    </div>
                )}
                 {selectedStyle.id === 'style_transfer' && (
                    <div className="bg-base-200/30 rounded-xl p-3 grid grid-cols-2 gap-2 border border-border-base">
                        {CHARACTER_STYLES.map(s => (
                            <button key={s.id} onClick={() => setSelectedCharStyle(s.id)} className={`p-2 rounded-lg text-[10px] font-bold border transition-all ${selectedCharStyle === s.id ? 'bg-pink-600 text-white' : 'border-border-base text-text-secondary hover:bg-base-200'}`}>{s.label}</button>
                        ))}
                    </div>
                )}
                {selectedStyle.id === 'ai_avatar' && (
                    <div className="bg-base-200/30 rounded-xl p-3 grid grid-cols-2 gap-2 border border-border-base">
                        {AVATAR_STYLES.map(a => (
                            <button key={a.id} onClick={() => setSelectedAvatarStyle(a.id)} className={`p-2 rounded-lg text-[10px] font-bold border transition-all ${selectedAvatarStyle === a.id ? 'bg-violet-600 text-white' : 'border-border-base text-text-secondary hover:bg-base-200'}`}>{a.label}</button>
                        ))}
                    </div>
                )}
            </div>

            {/* 4. Creativity & Prompt */}
            <div className="animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
                {selectedStyle.id !== 'color_correction' && selectedStyle.id !== 'old_photo_restore' && selectedStyle.id !== 'bg_changer' && (
                    <CreativitySlider value={creativityLevel} onChange={setCreativityLevel} />
                )}
                
                <PromptInput 
                    label={selectedStyle.id === 'dream_reconstruction' ? "صف الحلم (مثال: أجري في نفق مظلم)" : selectedStyle.id === 'memory_reconstruction' ? "صف الذاكرة (مثال: كنت في العاشرة في بيت جدي)" : "تعديلات إضافية (اختياري)"} 
                    value={imagePrompt} 
                    onChange={(e) => setImagePrompt(e.target.value)} 
                    placeholder={selectedStyle.id === 'dream_reconstruction' ? "اكتب تفاصيل الكابوس أو الحلم هنا..." : "اكتب وصفاً هنا..."} 
                    onEnhance={handleEnhancePrompt}
                    isEnhancing={isEnhancingPrompt}
                />
                
                {error && <p className="mt-4 text-xs text-red-500 bg-red-500/10 p-3 rounded-xl border border-red-500/20 animate-pulse">{error}</p>}
            </div>
         </div>

         {/* Footer - Static */}
         <div className="shrink-0 p-4 bg-base-100 border-t border-border-base z-10">
            <button 
                onClick={handleGenerateImage} 
                disabled={isLoadingImage || !originalImage} 
                className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-white shadow-lg transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:active:scale-100 group
                ${generatedImage ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-gradient-to-r from-primary to-indigo-600 hover:shadow-primary/30 hover:brightness-110'}`}
            >
                {isLoadingImage ? (
                    <span className="flex items-center gap-2">جاري التوليد...</span>
                ) : (
                    <>
                        {generatedImage ? 'إعادة المحاولة' : 'تنفيذ التعديل'}
                        <MagicWandIcon className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                    </>
                )}
            </button>
         </div>
      </aside>


      {/* === MAIN CANVAS (PREVIEW) === */}
      <main className="flex-1 bg-base-200/50 relative flex flex-col order-1 lg:order-2 h-[55vh] lg:h-full overflow-hidden transition-colors duration-300">
         {/* Grid Pattern Background */}
         <div className="absolute inset-0 pointer-events-none opacity-10" 
              style={{ backgroundImage: 'radial-gradient(var(--text-secondary) 1px, transparent 1px)', backgroundSize: '20px 20px' }}>
         </div>

         {/* Canvas Toolbar */}
         <div className="absolute top-4 left-4 z-10 flex gap-2">
             {generatedImage && (
                 <div className="flex gap-2 animate-fadeIn">
                    <button onClick={() => handleDownloadImage(generatedImage.base64, generatedImage.mimeType, 'art.png')} className="p-2.5 bg-base-100/80 backdrop-blur rounded-full text-text-main shadow-lg hover:bg-primary hover:text-white transition-all border border-border-base" title="تحميل">
                        <DownloadIcon className="w-5 h-5" />
                    </button>
                    <button onClick={() => handleShareImage(generatedImage.base64, generatedImage.mimeType)} className="p-2.5 bg-base-100/80 backdrop-blur rounded-full text-text-main shadow-lg hover:bg-sky-500 hover:text-white transition-all border border-border-base" title="مشاركة">
                        <ShareIcon className="w-5 h-5" />
                    </button>
                 </div>
             )}
             {generatedImage && originalImage && (
                 <button onClick={() => setIsCompareMode(!isCompareMode)} className={`px-4 py-2 rounded-full text-xs font-bold shadow-lg backdrop-blur transition-all border flex items-center gap-2 animate-fadeIn ${isCompareMode ? 'bg-primary text-white border-primary' : 'bg-base-100/80 text-text-main border-border-base hover:border-primary'}`}>
                     <ArrowsRightLeftIcon className="w-4 h-4" /> مقارنة
                 </button>
             )}
         </div>

         {/* The Stage */}
         <div className="flex-1 flex items-center justify-center p-4 sm:p-8 lg:p-12 relative">
             {!originalImage ? (
                 <div className="text-center opacity-30 flex flex-col items-center animate-fadeIn">
                     <div className="w-32 h-32 bg-base-300 rounded-full flex items-center justify-center mb-6">
                        <UploadIcon className="w-12 h-12 text-text-secondary" />
                     </div>
                     <p className="text-xl font-medium text-text-main">ابدأ برفع صورة</p>
                     <p className="text-sm text-text-secondary mt-2">لتحويلها إلى تحفة فنية</p>
                 </div>
             ) : (
                 <div className="relative w-full h-full max-w-4xl max-h-full flex items-center justify-center">
                     {isLoadingImage ? (
                         <div className="relative w-full max-w-lg aspect-[3/4] sm:aspect-square rounded-2xl shadow-2xl overflow-hidden">
                            <img src={`data:${originalImage.mimeType};base64,${originalImage.base64}`} className="w-full h-full object-cover opacity-50 blur-sm scale-105" />
                            <SkeletonLoader />
                         </div>
                     ) : generatedImage ? (
                         isCompareMode ? (
                             <CompareSlider 
                                originalSrc={`data:${originalImage.mimeType};base64,${originalImage.base64}`}
                                generatedSrc={`data:${generatedImage.mimeType};base64,${generatedImage.base64}`}
                                className="rounded-2xl shadow-2xl border border-border-base animate-fadeIn"
                             />
                         ) : (
                             <img 
                                src={`data:${generatedImage.mimeType};base64,${generatedImage.base64}`} 
                                className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl cursor-zoom-in transition-transform hover:scale-[1.01] animate-fadeIn" 
                                onClick={() => setLightboxSrc(`data:${generatedImage.mimeType};base64,${generatedImage.base64}`)}
                             />
                         )
                     ) : (
                        <img 
                            src={`data:${originalImage.mimeType};base64,${originalImage.base64}`} 
                            className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl animate-fadeIn"
                        />
                     )}
                 </div>
             )}
         </div>

         {/* Footer / History */}
         <div className="bg-base-100/90 backdrop-blur border-t border-border-base p-3 lg:p-4 flex justify-between items-center gap-4 z-10">
            {history.length > 0 ? (
                <div className="flex gap-3 overflow-x-auto scrollbar-hide py-2 px-2 max-w-[70vw]">
                    {history.map(item => (
                        <div key={item.id} onClick={() => setGeneratedImage({ base64: item.base64, mimeType: item.mimeType })} className={`w-12 h-12 lg:w-16 lg:h-16 flex-shrink-0 rounded-xl overflow-hidden cursor-pointer border-2 transition-all duration-300 hover:-translate-y-1 shadow-sm ${generatedImage?.base64 === item.base64 ? 'border-primary ring-2 ring-primary/30 scale-105' : 'border-transparent hover:border-base-300'}`}>
                            <img src={`data:${item.mimeType};base64,${item.base64}`} className="w-full h-full object-cover" />
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-xs text-text-secondary px-4 flex items-center gap-2">
                    <HistoryIcon className="w-4 h-4" />
                    السجل فارغ
                </div>
            )}
            
            <div className="flex gap-4 px-4 border-r border-border-base mr-auto">
                <a href="https://www.facebook.com/djamel.abdelli.7" target="_blank" className="text-text-secondary hover:text-[#1877F2] transition-colors"><FacebookIcon className="w-6 h-6" /></a>
                <a href="https://www.youtube.com/@djamelabdelli" target="_blank" className="text-text-secondary hover:text-[#FF0000] transition-colors"><YouTubeIcon className="w-6 h-6" /></a>
            </div>
         </div>
      </main>
    </div>
  );
}
